using System.Windows;
namespace CommunicationSoft { public partial class App : Application { } }