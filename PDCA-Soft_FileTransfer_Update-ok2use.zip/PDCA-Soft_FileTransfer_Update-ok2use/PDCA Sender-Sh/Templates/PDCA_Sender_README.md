# REFLOW-PDCA-SENDER – Barcode Query + 4 Template + TCP

## New workflow
1. Scan/enter **Panel SN**.
2. Click **Get Data (For Panel SN)**, or press Enter.
3. The application calls the editable `URL=` in `Config/server.txt`.
4. Put `{PANEL_SN}` in the URL wherever the scanned Panel SN must be inserted. `{JIGSN}` and `{PANEL}` are also accepted.
5. The HTTP response is parsed for four `GVD...` barcode values.
6. Barcode data 1–4 are shown separately.
7. Four PDCA templates are generated. The barcode becomes the first field in every template line; `Carrier_SN` and `pallet_sn` are populated with the Panel SN.
8. In **Auto** mode, all four generated templates are sent to the configured TCP IP/Port sequentially.
9. In **Manual** mode, each column has its own Generate and SEND button.
10. TCP response boxes turn light green for OK/SUCCESS/PASS and light red for failure.
11. Daily logs are written under `Logs\\yyyy-MM-dd.txt`.

## Config/server.txt
```text
IP=169.254.1.10
PORT=1111
URL=http://172.29.251.103/MLBAutoInterface/mlbauto.do?GET_BARCODE_PRE_DISTRIBUTE&info_type=JIG&upload_info={PANEL_SN}&jig_station=ST_JIG&carrier_station=SMT_INPUT2&line_name={LINE}
```

The URL is editable from the main window and can be saved with **Save Config**.

## Barcode response
Preferred response format is four values such as:
```text
GVD123456789123456, GVD123456789123456, GVD123456789123456, GVD123456789123456
```
The parser also accepts comma/newline separated GVD values and JSON/text responses containing the same 18-character GVD values.

## Template
The existing `Templates/pdca_template.txt` is reused. The barcode value replaces the text before the first `@`. `{BARCODE}` and `{PANEL_SN}` placeholders are also supported.
